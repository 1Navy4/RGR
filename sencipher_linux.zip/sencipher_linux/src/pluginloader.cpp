#include "pluginloader.h"
#include <iostream>
#include <dlfcn.h>

PluginLoader::PluginLoader() {
    dllHandle = nullptr;
}

PluginLoader::~PluginLoader() {
    if (dllHandle)
        dlclose(dllHandle);
}

CipherAPI* PluginLoader::loadCipher(
    const std::string& dllName,
    ReleaseCipherFunc& releaseFunc)
{
    // dlopen ищет файл так же, как обычная загрузка библиотек:
    // если имя без "/", будет использован путь поиска (LD_LIBRARY_PATH и т.д.).
    // Поэтому, если плагин лежит рядом с исполняемым файлом, лучше
    // передавать "./имя.so" — так и делает main.cpp.
    dllHandle = dlopen(dllName.c_str(), RTLD_NOW);

    if (!dllHandle) {
        // ЕСЛИ БИБЛИОТЕКА НЕ ЗАГРУЗИЛАСЬ, ВЫВОДИМ ТЕКСТ ОШИБКИ
        std::cout << "\n[СИСТЕМА] Ошибка dlopen для " << dllName
                  << ". " << dlerror() << "\n";
        return nullptr;
    }

    dlerror(); // сбрасываем предыдущую ошибку перед dlsym

    CreateCipherFunc createFunc =
        (CreateCipherFunc)dlsym(dllHandle, "createCipher");

    releaseFunc =
        (ReleaseCipherFunc)dlsym(dllHandle, "releaseCipher");

    const char* symError = dlerror();
    if (!createFunc || !releaseFunc || symError) {
        std::cout << "\n[СИСТЕМА] Функции экспорта не найдены в " << dllName
                  << (symError ? (std::string(". ") + symError) : "") << "\n";
        return nullptr;
    }

    return createFunc();
}
