#pragma once

// Под Windows экспорт функций из DLL требует __declspec(dllexport).
// Под Linux (.so) все внешние символы видны по умолчанию, поэтому
// специальный модификатор не нужен — но чтобы код компилировался
// на обеих платформах без правок, используем единый макрос.
#ifdef _WIN32
    #define PLUGIN_EXPORT extern "C" __declspec(dllexport)
#else
    #define PLUGIN_EXPORT extern "C"
#endif
